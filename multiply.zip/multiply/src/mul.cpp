#include "ros/ros.h" 
#include <std_msgs/Float64.h>
#include <sstream>

void Chattercallback(const std_msgs::Float64::ConstPtr& value)
{
ROS_INFO("%.2f",value->data);
}

int main(int argc, char **argv)
{
ros::init(argc,argv,"multiply");
ros::NodeHandle n;
ros::Subscriber sub=n.subscribe("number",1000,Chattercallback);
ros::spin();

return 0;
}
