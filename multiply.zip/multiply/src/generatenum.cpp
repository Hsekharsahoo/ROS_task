#include "ros/ros.h"
#include <std_msgs/Float64.h>
#include <sstream>

int main(int argc, char **argv)
{
ros::init(argc,argv,"generatenum");
ros::NodeHandle n;
ros:: Publisher chatter_pub=n.advertise<std_msgs::Float64>("number",1000);


float count1=5,count2=6;

std_msgs::Float64 num1,num2,prod;

num1.data=count1;
num2.data=count2;
prod.data=num1.data*num2.data;

ROS_INFO("%.2f",num1.data);
ROS_INFO("%.2f",num2.data);

while(chatter_pub.getNumSubscribers()<1)
{
}
chatter_pub.publish(prod);

ros::spinOnce();

return 0;
}

