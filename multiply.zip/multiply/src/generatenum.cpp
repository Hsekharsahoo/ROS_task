#include "ros/ros.h"
#include <std_msgs/Float64.h>
#include <sstream>

int main(int argc, char **argv)
{
ros::init(argc,argv,"generatenum");
ros::NodeHandle n;
ros:: Publisher chatter_pub=n.advertise<std_msgs::Float64>("number",1000);
ros:: Rate loop_rate(1);

float count1=1.0,count2=2.0,prod;
while(ros::ok())
{
std_msgs::Float64 num1,num2,prod;

num1.data=count1;
num2.data=count2;
prod.data=num1.data*num2.data;

ROS_INFO("%.2f",num1.data);
ROS_INFO("%.2f",num2.data);

chatter_pub.publish(prod);

ros::spinOnce();
loop_rate.sleep();
count1+=0.1;
count2+=0.2;
}
return 0;
}

